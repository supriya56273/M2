import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/shared/employee.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(public employeeService: EmployeeService) { }

  ngOnInit(): void {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null)
      form.resetForm();
    this.employeeService.formData = {
      employeeId: null,
      name: '',
      salary: null,
      department: ''
    }
  }

  onSubmit(form: NgForm) {
   if (this.employeeService.index == null)
      this.insertRecord(form);
    else{
      this.updateRecord(form);
      this.employeeService.index=null;
    }
  }
  checkNumber(employeeId){
  console.log(Number.isInteger(employeeId));
  }

  insertRecord(form: NgForm) {
    console.log('insert');
    this.employeeService.postEmployee(form.value);
    this.resetForm(form);
  }

  updateRecord(form: NgForm) {
    console.log('update');
    this.employeeService.putEmployee(form.value);
    this.resetForm(form);
  }
}
