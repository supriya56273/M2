export class Employee {
    employeeId: number;
    name: string;
    salary: number;
    department: string;
}
