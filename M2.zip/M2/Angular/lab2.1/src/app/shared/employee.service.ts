import { Injectable } from '@angular/core';
import { Employee } from './employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  formData: Employee;
  index=null;
  employees: Employee[] = [];

  constructor() {
  }

  //add new employee
  postEmployee(formData: Employee) {
    this.employees.push(formData);
    alert(formData.employeeId +' '+ formData.name + formData.salary + formData.department);
  }

  putEmployee(formData: Employee) {
    
    this.employees[this.index] = formData;
    alert(formData.employeeId +' '+ formData.name +' '+ formData.salary +' '+ formData.department);
  }

  deleteEmployee(id: number) {
    this.employees.splice(id, 1);
  }
}