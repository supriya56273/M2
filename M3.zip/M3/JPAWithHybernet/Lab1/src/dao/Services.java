package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import bean.Author;

public class Services {

	static EntityManagerFactory emfactory=Persistence.createEntityManagerFactory("FirstJPAProject");
	static EntityManager entitymanager=emfactory.createEntityManager();

	public static void main(String[] args)
	{
		Services service= new Services();
		
		Author authorObj = new Author();
		authorObj.setAuthorId(101);
		authorObj.setFirstName("Supriya");
		authorObj.setMiddleName("Sara");
		authorObj.setLastName("Singh");
		authorObj.setPhoneNo(8521479);
		service.InsertIntoAuthorDB(authorObj);
		
		Author authorObj1 = new Author();
		authorObj1.setAuthorId(102);
		authorObj1.setFirstName("Riya");
		authorObj1.setMiddleName("Sara");
		authorObj1.setLastName("Singh");
		authorObj1.setPhoneNo(7417417);
		service.InsertIntoAuthorDB(authorObj1);
		//System.out.println("===========Authors========");
		Author a=service.GetAuthorDetails(101);
		System.out.println("Author id : "+a.getAuthorId());
		System.out.println("Author name : "+a.getName());
		System.out.println("Author phone no : "+a.getPhoneNo());
		System.out.println("---------------------");
		Author a2=service.GetAuthorDetails(102);
		System.out.println("author details");
		System.out.println("Author id : "+a2.getAuthorId());
		System.out.println("Author name : "+a2.getName());
		System.out.println("Author phone no : "+a2.getPhoneNo());
		System.out.println("---------------------");
		service.UpdateAuthor(101,222222222);
		Author a1=service.GetAuthorDetails(102);
		System.out.println("Author id is : "+a1.getAuthorId());
		System.out.println("Author name : "+a1.getName());
		System.out.println("Author phone no : "+a1.getPhoneNo());
		service.DeleteAuthor(101);
	}
	public void InsertIntoAuthorDB(Author authorObj) {
		entitymanager.getTransaction().begin();
		entitymanager.persist(authorObj);
		entitymanager.getTransaction().commit();
		System.out.println("Author inserted successfully");
	}
	public void UpdateAuthor(int id,long phone) {
		entitymanager.getTransaction().begin();
		Author author = entitymanager.find(Author.class, id);
		author.setPhoneNo(phone);
		entitymanager.getTransaction().commit();
		System.out.println("Author phone no updated successfully");
	}
	Author GetAuthorDetails(int id) {
		Author author = entitymanager.find(Author.class, id);
		return author;
	}
	public void DeleteAuthor(int id) {
		entitymanager.getTransaction().begin();
		Author author = entitymanager.find(Author.class, id);
		entitymanager.remove(author);
		entitymanager.getTransaction().commit();
		System.out.println("Author deleted successfully");
	}
	
}