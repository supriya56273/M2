package com.authorLab2.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.authorLab2.bean.Author;
import com.authorLab2.bean.Book;

public class Dao {

	static EntityManagerFactory emfactory= Persistence.createEntityManagerFactory("JPALab2");
	static EntityManager entityManager= emfactory.createEntityManager();
	public Author getAuthorDetails(int authorId){
		Author author = entityManager.find(Author.class, authorId);
		return author;
	}
	public List<Book> getAllBooks(){
		Query bookQuery = entityManager.createNamedQuery("Book.findAll");
		List books = bookQuery.getResultList();
		return books;
	}
	

	
	public List<Book> getBooksInRange(){
		 Query query = entityManager.createQuery( "Select b from Book b  where b.price Between 500 and 1000" );
	      
	      List<Book> list=(List<Book>)query.getResultList( );
	      return list;
	}
	public String getAuthorByBookId(int isbn){
		Query query = entityManager.createQuery( "Select ba.author.name from BookAuthor ba  where ba.book.isbn="+isbn);
		String authName = (String) query.getSingleResult();
		return authName;
	}
}
