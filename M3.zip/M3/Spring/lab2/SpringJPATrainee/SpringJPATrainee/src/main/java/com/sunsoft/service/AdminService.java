package com.sunsoft.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sunsoft.Entity.AdminBean;

@Service
public interface AdminService {

	public Optional <AdminBean> getAdmin(String username);
}
