package com.sunsoft.service;

import java.util.List;
import java.util.Optional;

import com.sunsoft.Entity.AdminBean;
import com.sunsoft.Entity.TraineeSpringJPA;

public interface TraineeService {

	
	public List <TraineeSpringJPA> getTrainees();
	public void saveTrainee(TraineeSpringJPA theTrainee);
	public Optional <TraineeSpringJPA> getTrainee(int theId);
	public void deleteTrainee(int theId);
}
