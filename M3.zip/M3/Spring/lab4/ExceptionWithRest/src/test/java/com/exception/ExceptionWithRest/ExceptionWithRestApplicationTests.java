package com.exception.ExceptionWithRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionWithRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
